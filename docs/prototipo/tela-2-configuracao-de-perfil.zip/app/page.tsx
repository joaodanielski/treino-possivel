import { ProfileSetup } from '@/components/profile-setup'

export default function Page() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#111827] p-0 sm:p-4">
      <div className="relative flex h-dvh w-full max-w-sm flex-col overflow-hidden bg-[#111827] shadow-2xl sm:h-[844px] sm:max-h-[calc(100vh-2rem)] sm:rounded-[32px]">
        <div className="flex h-8 shrink-0 items-center justify-between bg-[#1F2937] px-6 text-[11px] font-medium text-white/80 sm:h-7">
          <span>9:41</span>
          <span aria-hidden="true" className="tracking-[0.18em]">••• ▰</span>
        </div>
        <ProfileSetup />
      </div>
    </div>
  )
}
