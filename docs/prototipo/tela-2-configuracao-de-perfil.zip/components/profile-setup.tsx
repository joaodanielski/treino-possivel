'use client'

import { useState } from 'react'
import { ArrowLeft, ChevronDown, Clock3, Dumbbell, Sparkles } from 'lucide-react'

const equipmentOptions = ['Peso corporal', 'Halteres', 'Barra', 'Academia Completa']

export function ProfileSetup() {
  const [goal, setGoal] = useState('Hipertrofia')
  const [days, setDays] = useState(4)
  const [minutes, setMinutes] = useState(45)
  const [equipment, setEquipment] = useState(['Halteres', 'Barra'])

  function toggleEquipment(item: string) {
    setEquipment((current) => current.includes(item) ? current.filter((value) => value !== item) : [...current, item])
  }

  return (
    <div className="flex min-h-full flex-col bg-[#111827] text-[#F9FAFB]">
      <header className="flex items-center gap-3 px-6 pb-5 pt-7">
        <button aria-label="Voltar" className="flex size-10 items-center justify-center rounded-full border border-white/10 bg-[#1F2937] text-[#9CA3AF] transition hover:bg-[#374151]">
          <ArrowLeft aria-hidden="true" />
        </button>
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#9CA3AF]">Vamos começar</p>
          <h1 className="mt-1 text-[26px] font-bold tracking-[-0.04em]">Seu Perfil</h1>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto px-6 pb-32">
        <div className="rounded-[22px] border border-white/10 bg-[#1F2937] p-4">
          <div className="flex items-start gap-3">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-[#374151] text-[#A3E635]"><Sparkles aria-hidden="true" /></div>
            <p className="text-sm leading-5 text-[#9CA3AF]">Conte um pouco sobre sua rotina. Vamos adaptar cada treino ao que você realmente tem disponível.</p>
          </div>
        </div>

        <form className="mt-7 flex flex-col gap-7" onSubmit={(event) => event.preventDefault()}>
          <label className="flex flex-col gap-2">
            <span className="text-[15px] font-semibold">Objetivo</span>
            <span className="relative">
              <select value={goal} onChange={(event) => setGoal(event.target.value)} className="h-14 w-full appearance-none rounded-2xl border border-white/10 bg-[#1F2937] px-4 text-[15px] font-medium shadow-[0_2px_8px_rgba(31,59,35,0.04)] outline-none transition focus:border-[#A3E635] focus:ring-4 focus:ring-[#A3E635]/20">
                <option>Hipertrofia</option><option>Emagrecimento</option><option>Manutenção</option>
              </select>
              <ChevronDown aria-hidden="true" className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
            </span>
          </label>

          <fieldset className="flex flex-col gap-3">
            <legend className="text-[15px] font-semibold">Dias disponíveis na semana</legend>
            <div className="grid grid-cols-7 gap-2 rounded-2xl border border-white/10 bg-[#1F2937] p-2 shadow-[0_2px_8px_rgba(31,59,35,0.04)]">
              {Array.from({ length: 7 }, (_, index) => index + 1).map((day) => (
                <button key={day} type="button" aria-pressed={days === day} onClick={() => setDays(day)} className={`flex aspect-square items-center justify-center rounded-xl text-sm font-semibold transition ${days === day ? 'bg-[#A3E635] text-[#111827] shadow-sm' : 'text-[#9CA3AF] hover:bg-[#374151]'}`}>
                  {day}
                </button>
              ))}
            </div>
            <p className="text-xs text-[#9CA3AF]">Você treinará <strong className="font-semibold text-[#9CA3AF]">{days} {days === 1 ? 'dia' : 'dias'}</strong> por semana.</p>
          </fieldset>

          <label className="flex flex-col gap-2">
            <span className="flex items-center justify-between text-[15px] font-semibold"><span>Tempo diário disponível</span><span className="rounded-lg bg-[#374151] px-2.5 py-1 text-sm font-bold text-[#A3E635]">{minutes} min</span></span>
            <span className="relative mt-2 flex h-14 items-center rounded-2xl border border-white/10 bg-[#1F2937] px-4 shadow-[0_2px_8px_rgba(31,59,35,0.04)]"><Clock3 aria-hidden="true" className="mr-3 text-[#9CA3AF]" /><input aria-label="Tempo diário disponível em minutos" type="range" min="15" max="120" step="5" value={minutes} onChange={(event) => setMinutes(Number(event.target.value))} className="h-1.5 w-full accent-[#A3E635]" /></span>
            <span className="flex justify-between text-xs text-[#9CA3AF]"><span>15 min</span><span>120 min</span></span>
          </label>

          <fieldset className="flex flex-col gap-3">
            <legend className="text-[15px] font-semibold">Equipamentos disponíveis</legend>
            <div className="grid grid-cols-2 gap-3">
              {equipmentOptions.map((item) => {
                const checked = equipment.includes(item)
                return <label key={item} className={`flex cursor-pointer items-center gap-3 rounded-2xl border p-3.5 text-sm font-medium transition ${checked ? 'border-[#A3E635]/60 bg-[#374151] text-[#F9FAFB]' : 'border-white/10 bg-[#1F2937] text-[#9CA3AF] hover:bg-[#374151]'}`}><input type="checkbox" checked={checked} onChange={() => toggleEquipment(item)} className="size-4 accent-[#A3E635]" />{item}</label>
              })}
            </div>
          </fieldset>
        </form>
      </main>

      <div className="absolute bottom-0 left-0 right-0 border-t border-white/10 bg-[#111827]/95 px-6 pb-6 pt-4 backdrop-blur-md">
        <button type="button" className="flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-[#A3E635] text-[15px] font-bold text-[#111827] shadow-[0_8px_20px_rgba(163,230,53,0.2)] transition hover:bg-[#bef264] active:scale-[0.99]"><Dumbbell aria-hidden="true" />Gerar Treino com IA</button>
      </div>
    </div>
  )
}

export default ProfileSetup

