import { Header } from '@/components/home/header'
import { WeekSummary } from '@/components/home/week-summary'
import { TrainingCards } from '@/components/home/training-cards'
import { BottomNav } from '@/components/home/bottom-nav'

export default function Page() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900 p-4">
      {/* Mobile Frame */}
      <div className="w-full max-w-sm bg-gray-950 rounded-3xl shadow-2xl overflow-hidden border border-gray-800 flex flex-col h-screen max-h-screen">
        {/* Status Bar */}
        <div className="bg-black px-6 py-2 flex justify-between items-center text-xs text-gray-400 border-b border-gray-800">
          <span>9:41</span>
          <div className="flex gap-1">
            <div className="w-4 h-3 border border-gray-600 rounded-sm"></div>
            <div className="w-4 h-3 border border-gray-600 rounded-sm"></div>
            <div className="w-4 h-3 border border-gray-600 rounded-sm fill-gray-600"></div>
          </div>
        </div>

        {/* App Content */}
        <div className="flex-1 flex flex-col overflow-hidden bg-gray-950">
          {/* Scrollable Content */}
          <div className="flex-1 overflow-y-auto">
            <Header />
            <WeekSummary />
            <TrainingCards />
          </div>

          {/* Bottom Navigation */}
          <BottomNav />
        </div>
      </div>
    </div>
  )
}
