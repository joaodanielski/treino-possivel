import { ActiveWorkoutScreen } from '@/components/active-workout/active-workout-screen'

export default function Page() {
  return <ActiveWorkoutScreen />
}

