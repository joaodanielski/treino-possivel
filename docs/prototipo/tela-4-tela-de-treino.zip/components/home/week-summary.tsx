import { ArrowUpRight, Flame } from 'lucide-react'

export function WeekSummary() {
  return (
    <section className="px-6 pb-6" aria-labelledby="week-title">
      <div className="flex items-end justify-between">
        <div>
          <p className="text-sm text-gray-400">Seu progresso</p>
          <h2 id="week-title" className="mt-1 text-xl font-bold text-white">Semana 3 <span className="text-gray-600">—</span> <span className="text-lime-400">Hipertrofia</span></h2>
        </div>
        <div className="flex items-center gap-1.5 rounded-full bg-orange-400/10 px-3 py-1.5 text-xs font-semibold text-orange-300">
          <Flame className="h-3.5 w-3.5" fill="currentColor" />
          5 dias
        </div>
      </div>
      <div className="mt-5 rounded-2xl bg-gray-900 p-4 ring-1 ring-inset ring-gray-800">
        <div className="mb-3 flex justify-between text-xs font-medium">
          <span className="text-gray-400">Treinos concluídos</span>
          <span className="text-white">2 de 3</span>
        </div>
        <div className="h-2 overflow-hidden rounded-full bg-gray-800">
          <div className="h-full w-2/3 rounded-full bg-lime-400" />
        </div>
        <div className="mt-4 flex items-center justify-between">
          <p className="text-xs text-gray-500">Você está no caminho certo!</p>
          <button className="flex items-center gap-1 text-xs font-semibold text-lime-400 hover:text-lime-300">Ver detalhes <ArrowUpRight className="h-3.5 w-3.5" /></button>
        </div>
      </div>
    </section>
  )
}
