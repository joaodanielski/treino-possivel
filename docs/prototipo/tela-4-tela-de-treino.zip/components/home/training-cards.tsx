import { Check, ChevronRight, Circle } from 'lucide-react'

const workouts = [
  { day: 'SEG', title: 'Treino A', subtitle: 'Pernas e Ombros', duration: '52 min', status: 'Concluído' },
  { day: 'QUA', title: 'Treino B', subtitle: 'Peito e Tríceps', duration: '48 min', status: 'Concluído' },
  { day: 'SEX', title: 'Treino C', subtitle: 'Costas e Bíceps', duration: '55 min', status: 'Pendente' },
]

export function TrainingCards() {
  return (
    <section className="px-6 pb-8" aria-labelledby="workouts-title">
      <div className="mb-4 flex items-center justify-between">
        <h2 id="workouts-title" className="text-lg font-bold text-white">Seus treinos</h2>
        <button className="text-xs font-semibold text-lime-400 hover:text-lime-300">Ver semana</button>
      </div>
      <div className="space-y-3">
        {workouts.map((workout) => {
          const completed = workout.status === 'Concluído'
          return (
            <button key={workout.title} className="group flex w-full items-center gap-4 rounded-2xl border border-gray-800 bg-gray-900 p-4 text-left transition hover:border-gray-700 hover:bg-gray-800">
              <div className={`flex h-12 w-12 shrink-0 flex-col items-center justify-center rounded-xl ${completed ? 'bg-lime-400/10 text-lime-400' : 'bg-gray-800 text-gray-500'}`}>
                <span className="text-[10px] font-bold tracking-wider">{workout.day}</span>
                <span className="mt-0.5 text-[9px]">18 JUN</span>
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="font-semibold text-white">{workout.title}</h3>
                <p className="mt-1 truncate text-xs text-gray-500">{workout.subtitle} <span className="text-gray-700">·</span> {workout.duration}</p>
              </div>
              <div className="flex flex-col items-end gap-2">
                <span className={`flex items-center gap-1.5 text-xs font-semibold ${completed ? 'text-lime-400' : 'text-gray-500'}`}>
                  {completed ? <Check className="h-3.5 w-3.5" strokeWidth={3} /> : <Circle className="h-3 w-3" />}
                  {workout.status}
                </span>
                <ChevronRight className="h-4 w-4 text-gray-600 transition group-hover:translate-x-0.5 group-hover:text-gray-400" />
              </div>
            </button>
          )
        })}
      </div>
    </section>
  )
}
