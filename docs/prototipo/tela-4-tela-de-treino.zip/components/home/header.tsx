import { Bell, Dumbbell } from 'lucide-react'

export function Header() {
  return (
    <header className="px-6 pt-6 pb-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-400">Segunda-feira, 21 de setembro</p>
          <h1 className="mt-1 text-2xl font-bold tracking-tight text-white">Olá, Lucas</h1>
        </div>
        <button aria-label="Abrir notificações" className="relative rounded-full bg-gray-800 p-3 text-gray-300 transition hover:bg-gray-700">
          <Bell className="h-5 w-5" strokeWidth={1.8} />
          <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-lime-400 ring-2 ring-gray-800" />
        </button>
      </div>
      <div className="mt-6 flex items-center gap-3 rounded-2xl border border-gray-800 bg-gray-900 px-4 py-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-lime-400 text-gray-950">
          <Dumbbell className="h-5 w-5" strokeWidth={2.4} />
        </div>
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-gray-500">Próximo treino</p>
          <p className="mt-0.5 text-sm font-semibold text-white">Treino B <span className="font-normal text-gray-500">· Peito e Tríceps</span></p>
        </div>
        <span className="ml-auto text-xs font-medium text-lime-400">Amanhã</span>
      </div>
    </header>
  )
} 
