'use client'

import { useEffect, useMemo, useState } from 'react'
import { ArrowLeft, Check, ChevronDown, Clock3, Dumbbell, MoreHorizontal, Pause, RotateCcw } from 'lucide-react'
import { Button } from '@/components/ui/button'

const initialSets = [
  { id: 1, weight: '20', reps: '12', completed: true },
  { id: 2, weight: '24', reps: '10', completed: true },
  { id: 3, weight: '24', reps: '10', completed: false },
  { id: 4, weight: '26', reps: '8', completed: false },
]

function formatTime(seconds: number) {
  const hours = Math.floor(seconds / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const remainingSeconds = seconds % 60
  return [hours, minutes, remainingSeconds].map((value) => String(value).padStart(2, '0')).join(':')
}

export function ActiveWorkoutScreen() {
  const [elapsed, setElapsed] = useState(930)
  const [isPaused, setIsPaused] = useState(false)
  const [sets, setSets] = useState(initialSets)

  useEffect(() => {
    if (isPaused) return
    const interval = window.setInterval(() => setElapsed((value) => value + 1), 1000)
    return () => window.clearInterval(interval)
  }, [isPaused])

  const completedCount = useMemo(() => sets.filter((set) => set.completed).length, [sets])
  const progress = Math.round((completedCount / sets.length) * 100)

  function toggleSet(id: number) {
    setSets((current) => current.map((set) => (set.id === id ? { ...set, completed: !set.completed } : set)))
  }

  function updateSet(id: number, field: 'weight' | 'reps', value: string) {
    setSets((current) => current.map((set) => (set.id === id ? { ...set, [field]: value } : set)))
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-[#0b1120] font-sans text-[#F9FAFB]">
      <div className="flex h-dvh w-full max-w-[430px] flex-col overflow-hidden bg-[#111827] shadow-2xl sm:h-[860px] sm:rounded-[32px] sm:border sm:border-white/10">
        <header className="shrink-0 border-b border-white/10 bg-[#111827] px-5 pb-5 pt-4">
          <div className="mb-6 flex items-center justify-between">
            <Button aria-label="Voltar" variant="ghost" size="icon" className="size-10 rounded-full text-[#9CA3AF] hover:bg-white/10 hover:text-white">
              <ArrowLeft className="size-5" />
            </Button>
            <span className="text-xs font-semibold uppercase tracking-[0.18em] text-[#9CA3AF]">Treino de hoje</span>
            <Button aria-label="Mais opções" variant="ghost" size="icon" className="size-10 rounded-full text-[#9CA3AF] hover:bg-white/10 hover:text-white">
              <MoreHorizontal className="size-5" />
            </Button>
          </div>

          <div className="flex items-end justify-between">
            <div>
              <div className="mb-2 flex items-center gap-2 text-sm text-[#9CA3AF]"><Clock3 className="size-4 text-[#A3E635]" /> Tempo de treino</div>
              <p className="font-mono text-[36px] font-bold leading-none tracking-[-0.05em] tabular-nums">{formatTime(elapsed)}</p>
            </div>
            <Button onClick={() => setIsPaused((value) => !value)} variant="ghost" className="mb-0.5 h-10 rounded-xl border border-white/10 bg-[#1F2937] px-3 text-[#F9FAFB] hover:bg-[#374151]">
              {isPaused ? <RotateCcw className="mr-2 size-4 text-[#A3E635]" /> : <Pause className="mr-2 size-4 text-[#A3E635]" />}
              {isPaused ? 'Retomar' : 'Pausar'}
            </Button>
          </div>
        </header>

        <section className="flex-1 overflow-y-auto px-5 pb-6 pt-6">
          <div className="mb-7 flex items-start justify-between">
            <div>
              <p className="mb-2 text-sm font-medium text-[#9CA3AF]">Exercício 2 de 6</p>
              <h1 className="text-[29px] font-bold leading-tight tracking-[-0.04em]">Agachamento Livre</h1>
              <p className="mt-2 flex items-center gap-1.5 text-sm text-[#9CA3AF]"><Dumbbell className="size-4" /> Descanso de 90s entre séries</p>
            </div>
            <button aria-label="Selecionar exercício" className="mt-1 rounded-xl bg-[#374151] p-2.5 text-[#9CA3AF] transition-colors hover:text-white"><ChevronDown className="size-5" /></button>
          </div>

          <div className="mb-5 rounded-2xl border border-white/10 bg-[#1F2937] p-4">
            <div className="mb-3 flex items-center justify-between text-sm">
              <span className="font-semibold">Progresso do exercício</span>
              <span className="font-semibold text-[#A3E635]">{completedCount}/{sets.length} séries</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-[#374151]" role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}>
              <div className="h-full rounded-full bg-[#A3E635] transition-all duration-300" style={{ width: `${progress}%` }} />
            </div>
          </div>

          <div className="mb-3 grid grid-cols-[1fr_78px_78px_52px] items-center gap-2 px-3 text-[11px] font-semibold uppercase tracking-[0.12em] text-[#9CA3AF]">
            <span>Série</span><span className="text-center">Carga</span><span className="text-center">Reps</span><span className="sr-only">Concluir</span>
          </div>

          <div className="space-y-2.5">
            {sets.map((set) => (
              <div key={set.id} className={`grid grid-cols-[1fr_78px_78px_52px] items-center gap-2 rounded-2xl border p-3 transition-colors ${set.completed ? 'border-[#22C55E]/30 bg-[#1c3327]' : 'border-white/10 bg-[#1F2937]'}`}>
                <span className={`text-sm font-semibold ${set.completed ? 'text-[#22C55E]' : 'text-[#F9FAFB]'}`}>Série {set.id}</span>
                <label className="sr-only" htmlFor={`weight-${set.id}`}>Carga da série {set.id} em quilogramas</label>
                <input id={`weight-${set.id}`} inputMode="decimal" value={set.weight} onChange={(event) => updateSet(set.id, 'weight', event.target.value)} className="h-11 w-full rounded-xl border border-white/10 bg-[#374151] px-2 text-center text-base font-bold text-white outline-none transition focus:border-[#A3E635] focus:ring-2 focus:ring-[#A3E635]/20" aria-label={`Carga da série ${set.id} em quilogramas`} />
                <label className="sr-only" htmlFor={`reps-${set.id}`}>Repetições da série {set.id}</label>
                <input id={`reps-${set.id}`} inputMode="numeric" value={set.reps} onChange={(event) => updateSet(set.id, 'reps', event.target.value)} className="h-11 w-full rounded-xl border border-white/10 bg-[#374151] px-2 text-center text-base font-bold text-white outline-none transition focus:border-[#A3E635] focus:ring-2 focus:ring-[#A3E635]/20" aria-label={`Repetições da série ${set.id}`} />
                <button type="button" onClick={() => toggleSet(set.id)} aria-label={`${set.completed ? 'Desmarcar' : 'Marcar'} série ${set.id} como concluída`} className={`ml-1 flex size-12 items-center justify-center rounded-full border-2 transition-all active:scale-95 ${set.completed ? 'border-[#22C55E] bg-[#22C55E] text-[#111827]' : 'border-[#9CA3AF] bg-transparent text-transparent hover:border-[#A3E635]'}`}><Check className="size-6 stroke-[3]" /></button>
              </div>
            ))}
          </div>
        </section>

        <footer className="shrink-0 border-t border-white/10 bg-[#111827] p-5 pb-7">
          <Button className="h-14 w-full rounded-2xl bg-[#A3E635] text-base font-bold text-[#17200b] shadow-[0_8px_24px_rgba(163,230,53,0.18)] hover:bg-[#bef264] active:scale-[0.99]">
            Finalizar Treino <Check className="ml-2 size-5 stroke-[3]" />
          </Button>
        </footer>
      </div>
    </main>
  )
}
