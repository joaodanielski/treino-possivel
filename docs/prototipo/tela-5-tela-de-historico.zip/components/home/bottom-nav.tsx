import { Clock3, Home, UserRound } from 'lucide-react'

const tabs = [
  { label: 'Início', icon: Home, active: false },
  { label: 'Histórico', icon: Clock3, active: true },
  { label: 'Perfil', icon: UserRound, active: false },
]

export function BottomNav() {
  return (
    <nav className="shrink-0 border-t border-gray-800 bg-gray-950 px-8 pb-5 pt-3" aria-label="Navegação principal">
      <div className="flex items-center justify-between">
        {tabs.map(({ label, icon: Icon, active }) => (
          <button key={label} className={`flex min-w-16 flex-col items-center gap-1.5 text-xs font-medium transition ${active ? 'text-lime-400' : 'text-gray-600 hover:text-gray-300'}`} aria-current={active ? 'page' : undefined}>
            <Icon className="h-5 w-5" strokeWidth={active ? 2.5 : 1.8} />
            <span>{label}</span>
          </button>
        ))}
      </div>
    </nav>
  )
}
