import { Check, ChevronRight, CircleX } from 'lucide-react'

type Workout = {
  date: string
  day: string
  name: string
  status: 'Concluído' | 'Faltou'
}

const sections: { title: string; items: Workout[] }[] = [
  {
    title: 'Semana Passada',
    items: [
      { date: '18', day: 'Seg', name: 'Treino A - Peito e Tríceps', status: 'Concluído' },
      { date: '20', day: 'Qua', name: 'Treino B - Pernas', status: 'Concluído' },
      { date: '22', day: 'Sex', name: 'Treino C - Costas e Bíceps', status: 'Faltou' },
    ],
  },
  {
    title: 'Neste Mês',
    items: [
      { date: '04', day: 'Seg', name: 'Treino A - Peito e Tríceps', status: 'Concluído' },
      { date: '06', day: 'Qua', name: 'Treino B - Pernas', status: 'Concluído' },
    ],
  },
]

export function HistoryList() {
  return (
    <main className="flex flex-1 flex-col overflow-y-auto px-5 pb-8 pt-7">
      <header className="mb-8">
        <p className="mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-lime-400">Atividade</p>
        <h1 className="text-3xl font-bold tracking-tight text-gray-50">Seu Histórico</h1>
        <p className="mt-2 text-sm text-gray-400">Acompanhe sua jornada, um treino por vez.</p>
      </header>

      <div className="flex flex-col gap-8">
        {sections.map((section) => (
          <section key={section.title} aria-labelledby={section.title.replace(' ', '-')}>
            <h2 id={section.title.replace(' ', '-')} className="mb-3 text-sm font-semibold text-gray-300">
              {section.title}
            </h2>
            <div className="overflow-hidden rounded-2xl border border-white/10 bg-gray-800/90">
              {section.items.map((workout, index) => {
                const completed = workout.status === 'Concluído'
                return (
                  <button
                    key={`${section.title}-${workout.date}`}
                    type="button"
                    className="group flex w-full items-center gap-3 border-b border-white/10 px-3 py-4 text-left transition last:border-b-0 hover:bg-gray-700/60 focus-visible:bg-gray-700/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-lime-400"
                    aria-label={`${workout.date} de ${workout.day}, ${workout.name}, ${workout.status}`}
                  >
                    <span className="flex size-11 shrink-0 flex-col items-center justify-center rounded-xl bg-gray-700 text-gray-50">
                      <span className="text-lg font-bold leading-none">{workout.date}</span>
                      <span className="mt-1 text-[10px] font-medium uppercase text-gray-400">{workout.day}</span>
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold text-gray-100">{workout.name}</span>
                      <span className={`mt-1.5 inline-flex items-center gap-1 text-xs font-medium ${completed ? 'text-green-400' : 'text-red-400'}`}>
                        {completed ? <Check aria-hidden="true" className="size-3.5" /> : <CircleX aria-hidden="true" className="size-3.5" />}
                        {workout.status}
                      </span>
                    </span>
                    <ChevronRight aria-hidden="true" className="size-4 shrink-0 text-gray-600 transition group-hover:text-gray-300" />
                  </button>
                )
              })}
            </div>
          </section>
        ))}
      </div>
    </main>
  )
}
