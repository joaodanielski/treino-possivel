import { BottomNav } from '@/components/home/bottom-nav'
import { HistoryList } from '@/components/home/history-list'

export default function Page() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-900 p-4">
      <div className="flex h-screen max-h-screen w-full max-w-sm flex-col overflow-hidden rounded-3xl border border-gray-800 bg-gray-950 shadow-2xl">
        <div className="flex items-center justify-between border-b border-gray-800 bg-black px-6 py-2 text-xs text-gray-400">
          <span>9:41</span>
          <div className="flex gap-1" aria-label="Status da conexão">
            <span className="h-3 w-4 rounded-sm border border-gray-600" />
            <span className="h-3 w-4 rounded-sm border border-gray-600" />
            <span className="h-3 w-4 rounded-sm border border-gray-600 bg-gray-600" />
          </div>
        </div>
        <div className="flex min-h-0 flex-1 flex-col overflow-hidden bg-[#111827]">
          <HistoryList />
          <BottomNav />
        </div>
      </div>
    </div>
  )
}
