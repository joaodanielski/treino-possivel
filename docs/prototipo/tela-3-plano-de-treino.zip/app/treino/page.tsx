'use client'

import { useState } from 'react'
import { ArrowLeft, RefreshCw, Sparkles, X } from 'lucide-react'
import Link from 'next/link'

interface Exercise {
  id: string
  name: string
  sets: number
  reps: string
}

interface TrainingPlan {
  id: string
  title: string
  description: string
  exercises: Exercise[]
}

export default function TrainingPage() {
  const [trainingPlan] = useState<TrainingPlan>({
    id: '1',
    title: 'Treino A - Peito e Tríceps',
    description: 'Plano gerado para fortalecer peito e tríceps',
    exercises: [
      { id: '1', name: 'Supino Reto', sets: 4, reps: '8-10' },
      { id: '2', name: 'Supino Inclinado', sets: 3, reps: '10-12' },
      { id: '3', name: 'Fly com Halteres', sets: 3, reps: '12-15' },
      { id: '4', name: 'Rosca Tríceps na Polia', sets: 3, reps: '10-12' },
      { id: '5', name: 'Mergulho Assistido', sets: 3, reps: '8-12' },
      { id: '6', name: 'Rosca Unilateral Tríceps', sets: 2, reps: '12-15' },
    ],
  })

  const [selectedExerciseId, setSelectedExerciseId] = useState<string | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  const handleSubstituteExercise = (exerciseId: string) => {
    setSelectedExerciseId(exerciseId)
    setIsModalOpen(true)
  }

  const handleCloseModal = () => {
    setIsModalOpen(false)
    setSelectedExerciseId(null)
  }

  const selectedExercise = trainingPlan.exercises.find(e => e.id === selectedExerciseId)

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900 p-4">
      {/* Mobile Frame */}
      <div className="w-full max-w-sm bg-gray-950 rounded-3xl shadow-2xl overflow-hidden border border-gray-800 flex flex-col h-screen max-h-screen">
        {/* Status Bar */}
        <div className="bg-black px-6 py-2 flex justify-between items-center text-xs text-gray-400 border-b border-gray-800">
          <span>9:41</span>
          <div className="flex gap-1">
            <div className="w-4 h-3 border border-gray-600 rounded-sm"></div>
            <div className="w-4 h-3 border border-gray-600 rounded-sm"></div>
            <div className="w-4 h-3 border border-gray-600 rounded-sm fill-gray-600"></div>
          </div>
        </div>

        {/* App Content */}
        <div className="flex-1 flex flex-col overflow-hidden bg-gray-950">
          {/* Header */}
          <div className="shrink-0 border-b border-white/10 bg-gray-950 px-6 py-4">
            <div className="flex items-center gap-3 mb-4">
              <Link href="/" className="text-gray-400 hover:text-gray-200 transition">
                <ArrowLeft className="h-5 w-5" />
              </Link>
              <h1 className="text-lg font-semibold text-gray-100">Novo Treino</h1>
            </div>
          </div>

          {/* Scrollable Content */}
          <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
            {/* AI Badge */}
            <div className="flex justify-center">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-lime-400/20 to-lime-500/20 border border-lime-400/50 shadow-lg shadow-lime-400/20">
                <Sparkles className="h-4 w-4 text-lime-400 fill-lime-400" />
                <span className="text-sm font-semibold text-lime-300">Gerado por IA</span>
              </div>
            </div>

            {/* Training Title */}
            <div className="space-y-2">
              <h2 className="text-2xl font-bold text-gray-100">{trainingPlan.title}</h2>
              <p className="text-sm text-gray-400">{trainingPlan.description}</p>
            </div>

            {/* Exercises List */}
            <div className="space-y-3">
              {trainingPlan.exercises.map((exercise) => (
                <div
                  key={exercise.id}
                  className="group rounded-xl bg-gray-900 border border-white/10 p-4 hover:border-white/20 transition-all hover:shadow-lg hover:shadow-black/20"
                >
                  {/* Exercise Header */}
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="text-base font-semibold text-gray-100 flex-1">{exercise.name}</h3>
                  </div>

                  {/* Exercise Details */}
                  <div className="flex items-center gap-4 mb-4">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium text-gray-400 uppercase tracking-wide">Séries</span>
                      <span className="text-lg font-bold text-lime-400">{exercise.sets}</span>
                    </div>
                    <div className="h-4 w-px bg-white/10"></div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium text-gray-400 uppercase tracking-wide">Reps</span>
                      <span className="text-lg font-bold text-lime-400">{exercise.reps}</span>
                    </div>
                  </div>

                  {/* Substitute Button */}
                  <button
                    onClick={() => handleSubstituteExercise(exercise.id)}
                    className="w-full inline-flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg bg-gray-800/50 hover:bg-gray-800 border border-gray-700 hover:border-gray-600 text-sm font-medium text-gray-300 hover:text-gray-100 transition-all group/btn"
                  >
                    <RefreshCw className="h-4 w-4 group-hover/btn:rotate-180 transition-transform duration-300" />
                    <span>Substituir exercício</span>
                  </button>
                </div>
              ))}
            </div>

            {/* Padding for footer */}
            <div className="h-4"></div>
          </div>

          {/* Accept Button - Fixed Footer */}
          <div className="shrink-0 border-t border-white/10 bg-gray-950 px-6 py-4">
            <button className="w-full rounded-lg bg-gradient-to-r from-lime-400 to-lime-500 hover:from-lime-300 hover:to-lime-400 text-gray-950 font-semibold py-3 transition-all shadow-lg shadow-lime-400/20 hover:shadow-lg hover:shadow-lime-400/40">
              Aceitar Plano
            </button>
          </div>
        </div>
      </div>

      {/* Modal Overlay */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-end z-50">
          <div className="w-full max-w-sm bg-gray-950 rounded-t-2xl border-t border-white/10 p-6 space-y-4 animate-in slide-in-from-bottom duration-300">
            {/* Modal Header */}
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-100">Substituir Exercício</h3>
              <button
                onClick={handleCloseModal}
                className="text-gray-400 hover:text-gray-200 transition"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Current Exercise Info */}
            {selectedExercise && (
              <div className="rounded-lg bg-gray-900 border border-white/10 p-4">
                <p className="text-xs font-medium text-gray-400 mb-1 uppercase">Exercício Atual</p>
                <p className="text-base font-semibold text-gray-100">{selectedExercise.name}</p>
              </div>
            )}

            {/* Suggested Alternatives */}
            <div className="space-y-2">
              <p className="text-xs font-medium text-gray-400 mb-3 uppercase">Alternativas Sugeridas</p>
              {[
                'Supino com Halteres',
                'Supino Máquina',
                'Press de Peito',
              ].map((alt, idx) => (
                <button
                  key={idx}
                  className="w-full text-left rounded-lg bg-gray-900 hover:bg-gray-800 border border-white/10 hover:border-lime-400/50 p-3 transition-all group"
                >
                  <p className="text-sm font-medium text-gray-100 group-hover:text-lime-400 transition">{alt}</p>
                </button>
              ))}
            </div>

            {/* Modal Actions */}
            <div className="flex gap-3 pt-2">
              <button
                onClick={handleCloseModal}
                className="flex-1 rounded-lg bg-gray-900 hover:bg-gray-800 border border-gray-700 text-gray-300 font-medium py-2.5 transition"
              >
                Cancelar
              </button>
              <button className="flex-1 rounded-lg bg-gradient-to-r from-lime-400 to-lime-500 hover:from-lime-300 hover:to-lime-400 text-gray-950 font-semibold py-2.5 transition">
                Confirmar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
