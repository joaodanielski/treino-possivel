export { default } from './treino/page'
